export interface Prodotto {
  targa: string;
  marca: string;
  modello: string;
  prezzo: number;
  quantita: number;
}
