export interface Fornitore {
  piva: string;
  nome: string;
  cognome?: string;
  telefono?: string;
  casaProduttrice?: string;
  preferenze?: boolean;
}
